The sample code demonstrates how to capture command line input arguments
